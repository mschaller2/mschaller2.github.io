mocha.setup({
  ui: 'tdd',
  slow: 1000,
  timeout: 30000
});
