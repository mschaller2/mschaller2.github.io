polymer-all
===============

Combination of polymer, projects, polymer-elements, polymer-ui-elements, and more-elements repositories for easy cloning.
